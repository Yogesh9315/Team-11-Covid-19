This COVID-19 Dashboard is a web application that provides real-time data visualization of the ongoing pandemic. 
It displays global and country-specific statistics, including cases, deaths, and recoveries. 
The dashboard is built using HTML, CSS, JavaScript, and various libraries such as Highcharts, Chart.js, and Bootstrap.

Features:
->Global and country-specific data visualization
->Interactive maps and charts
->Data filters and sorting options
->Real-time data updates
->Responsive design for various devices and screen sizes

Prerequisites
To run the application, you will need the following software installed on your system:

A modern web browser (Chrome, Firefox, Safari, or Edge)
A local web server (e.g., Apache, Nginx, or the built-in Python HTTP server)

Installation and Setup
Download the project files from the GitHub repository.

Extract the downloaded archive to a directory on your local web server.

Ensure that the web server is configured to serve the project's directory.

Running the Application

Start your local web server (if it's not already running).

Open your web browser and navigate to the URL corresponding to the project's directory on your local web server (e.g., http://localhost/covid-dashboard).

The COVID-19 Dashboard should load, and you can now explore the various visualizations and features.





