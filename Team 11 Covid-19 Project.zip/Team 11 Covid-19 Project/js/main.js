$(function () {
    //const api_url = "https://disease.sh/v3/covid-19/all";
    const api_url = "https://disease.sh/v3/covid-19/countries";

  /*
    $.getJSON(api_url, function (data) {
      $("#data-refersh").append(data.updated);
      $(".active-case").append(data.active.toLocaleString());
      $(".total-cases").append(data.cases.toLocaleString());
      $(".total-death").append(data.deaths.toLocaleString());
  
      createWorldMap(data);
      createBarChart();
      createPieChart(data);
      createDataTable();
      createWorldMap(countriesData);
    });
  */


    $.getJSON(api_url, function (data) {
    // Calculate total data for the dashboard
    const totalData = data.reduce((acc, curr) => ({
        updated: Math.max(acc.updated, curr.updated),
        active: acc.active + curr.active,
        cases: acc.cases + curr.cases,
        deaths: acc.deaths + curr.deaths,
        recovered: acc.recovered + curr.recovered
    }), {
        updated: 0,
        active: 0,
        cases: 0,
        deaths: 0,
        recovered: 0
    });

    $("#data-refersh").append(totalData.updated);
    $(".active-case").append(totalData.active.toLocaleString());
    $(".total-cases").append(totalData.cases.toLocaleString());
    $(".total-death").append(totalData.deaths.toLocaleString());

    createWorldMap(data);
    createBarChart();
    createPieChart(totalData);
    createDataTable();
    });

    

 
    function createWorldMap(data) {
        if (!Array.isArray(data)) {
          console.error("Error: Data received is not an array");
          return;
        }
      
        // Convert data to an array of objects containing country code and cases
        const mapData = data.map((item) => ({
          'hc-key': item.countryInfo.iso2 && item.countryInfo.iso2.toLowerCase(),
          'value': item.cases,
        }));
      
        Highcharts.mapChart('world-map', {
          chart: {
            map: 'custom/world',
          },
          title: {
            text: 'COVID-19 Cases by Country',
          },
          subtitle: {
            text: 'Source: <a href="https://disease.sh/">disease.sh</a>',
          },
          mapNavigation: {
            enabled: true,
            buttonOptions: {
              verticalAlign: 'bottom',
            },
          },
          colorAxis: {
            min: 0,
          },
          series: [
            {
              data: mapData,
              name: 'COVID-19 Cases',
              states: {
                hover: {
                  color: '#BADA55',
                },
              },
              dataLabels: {
                enabled: true,
                format: '{point.name}',
              },
            },
          ],
        });
      }
      
  
    function createBarChart() {
      const bar_chart_url = "https://disease.sh/v3/covid-19/countries?sort=cases";
  
      $.getJSON(bar_chart_url, function (data) {
        
        const countries = data.slice(0, 10).map((item) => item.country);
        const cases = data.slice(0, 10).map((item) => item.cases);
  
        const ctx = document.getElementById("bar-chart").getContext("2d");
        const barChart = new Chart(ctx, {
          type: "bar",
          data: {
            labels: countries,
            datasets: [
              {
                label: "Cases",
                data: cases,
                backgroundColor: "rgba(75, 192, 192, 0.2)",
                borderColor: "rgba(75, 192, 192, 1)",
                borderWidth: 1,
              },
            ],
          },
          options: {
            scales: {
              y: {
                beginAtZero: true,
              },
            },
          },
        });
      });
    }
  
    function createPieChart(data) {
      const ctx = document.getElementById("pie-chart").getContext("2d");
      const pieChart = new Chart(ctx, {
        type: "pie",
        data: {
          labels: ["Cases", "Deaths", "Recovered"],
          datasets: [
            {
              data: [data.cases, data.deaths, data.recovered],
              backgroundColor: ["#36A2EB", "#FF6384", "#FFCE56"],
              hoverBackgroundColor: ["#36A2EB", "#FF6384", "#FFCE56"],
            },
          ],
        },
      });
    }
  
    function createDataTable() {
      const datatable_url = "https://disease.sh/v3/covid-19/countries";
  
      $.getJSON(datatable_url, function (data) {
        const tableBody = $("#datatable-body");
  
        data.forEach((item) => {
          const row = `<tr>
            <td>${item.country}</td>
            <td>${item.active.toLocaleString()}</td>
            <td>${item.cases.toLocaleString()}</td>
            <td>${item.deaths.toLocaleString()}</td>
          </tr>`;
          tableBody.append(row);
        });
  
        $("#datatable").DataTable();
      });
    }
  });
  
  